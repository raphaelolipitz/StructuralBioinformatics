import argparse
import sys
from pathlib import Path

import pandas as pandas
from matplotlib import pyplot as pl
import numpy as np
from Bio.PDB import PDBParser, is_aa
import operator
from glob import glob

from matplotlib.backends.backend_pgf import PdfPages

amino_acids_frequency_aHelix = {"ALA": 0, "ASX": 0, "CYS": 0, "ASP": 0, "GLU": 0, "PHE": 0, "GLY": 0, "HIS": 0,
                                "ILE": 0,
                                "LYS": 0, "LEU": 0, "MET": 0, "ASN": 0, "PRO": 0, "GLN": 0, "ARG": 0, "SER": 0,
                                "THR": 0,
                                "SEC": 0, "VAL": 0, "TRP": 0, "XAA": 0, "TYR": 0, "GLX": 0}
amino_acids_frequency_bsheet = {"ALA": 0, "ASX": 0, "CYS": 0, "ASP": 0, "GLU": 0, "PHE": 0, "GLY": 0, "HIS": 0,
                                "ILE": 0,
                                "LYS": 0, "LEU": 0, "MET": 0, "ASN": 0, "PRO": 0, "GLN": 0, "ARG": 0, "SER": 0,
                                "THR": 0,
                                "SEC": 0, "VAL": 0, "TRP": 0, "XAA": 0, "TYR": 0, "GLX": 0}
hist_list_aHelix = []
protein_length = 0
hist_list = []
length_helix_alpha = 0
length_helix_31 = 0
length_sheet = 0
sorted_aHelix = {}
sorted_bSheet = {}

# functions:
'''
def print_histo_for_aHelix(liste):
    n, bins, patches = pl.hist(x=hist_list_aHelix, bins='auto', color='#0504aa',
                               alpha=0.7, rwidth=0.85)
    pl.grid(axis='y', alpha=0.75)
    pl.xlabel('Distance')
    pl.ylabel('Frequency')
    pl.title('Distances in alpha Helices' + str(structure_id))
    pl.text(23, 45, r'$\mu=15, b=3$')
    maxfreq = n.max()
    # plt.show()

    pl.savefig(fname = structure_id, format='pdf')
    pl.close()
'''


def print_histo_for_protein(liste1, list2):
    pl.hist(x=hist_list, bins='auto', color='#0504aa',
            alpha=0.7, rwidth=0.85, label='aHelix')
    pl.hist(x=hist_list_aHelix, bins='auto',
            alpha=0.7, rwidth=0.85, label='allProtein', color="green")
    pl.grid(axis='y', alpha=0.75)
    pl.xlabel('Distance')
    pl.ylabel('Frequency')
    pl.title('Distances of complete Protein' + str(structure_id))
    pl.text(23, 45, r'$\mu=15, b=3$')
    pl.legend(loc='upper right')

    # plt.show()
    pl.savefig(fname=structure_id, format='pdf')
    pl.close()


print('Python Version :' + sys.version)
print('Numpy Version :' + np.__version__)
print('Argparse Version :' + argparse.__version__)

parser = argparse.ArgumentParser(description='Plotting and calculating secundary Stuff of Proteins')

parser.add_argument('-i', type=Path)

args = parser.parse_args()
path1 = args.i

path = str(args.i) + '/*'

files = glob(path)

for filename in files:
    with open(filename) as file:

        p = PDBParser()
        structure_id = filename[-8:-4]
        structure = p.get_structure(structure_id, filename)
        residues_list = list(structure.get_residues())
        model = structure[0]
        print(structure)
        # for r in range(3, len(residues_list)):
        # residue1 = residues_list[r]
        # residue2 = residues_list[r - 4]
        # if is_aa(residue1, standard=True):
        # if is_aa(residue2, standard=True):
        # try:
        # c = residue1['CA'].get_vector()
        # o = residue1['O'].get_vector()
        # hist_list.append(np.linalg.norm(c - o))
        # except Exception:
        # continue
        # for model in structure:
        # for chain in model:
        # for residue in chain:
        # for atom in residue:
        # protein_length += 1

        # print(protein_length)

        # for model in structure:
        # for chain in model:
        # for residue in chain:
        # if is_aa(residue, standard=True):
        # residue.get_resname()
        # print(residue)

        while True:
            line = file.readline()

            try:
                if 'HELIX' in line:
                    helix = line
                    if helix[39:40] == '1':
                        start = int(helix[22:25])
                        end = int(helix[34:37])
                        length_helix_alpha += int(helix[72:76])

                        for r in range(start, end):
                            res = residues_list[r]
                            if is_aa(res, standard=True):
                                residue = residues_list[r]
                                acid = str(residue.get_resname())

                                for keys in amino_acids_frequency_aHelix:
                                    if acid in amino_acids_frequency_aHelix:
                                        amino_acids_frequency_aHelix[acid] += 1

                        for r in range(3, len(residues_list)):
                            residue1 = residues_list[r]
                            residue2 = residues_list[r - 4]
                            if is_aa(residue1, standard=True):
                                if is_aa(residue2, standard=True):
                                    try:
                                        c = residue1['CA'].get_vector()
                                        o = residue1['O'].get_vector()
                                        hist_list_aHelix.append(np.linalg.norm(c - o))
                                    except Exception:
                                        pass
            except Exception:
                pass
                try:
                    if helix[39:40] == '5':
                        start = int(helix[22:25])
                        end = int(helix[34:37])
                        length_helix_31 += int(helix[72:76])
                except Exception:
                    pass
            try:
                if 'SHEET' in line:
                    sheet = line
                    start = int(sheet[23:26])
                    end = int(sheet[34:37])
                    length_sheet += end - start

                    for r in range(start, end):
                        res = residues_list[r]
                        if is_aa(res, standard=True):
                            residue = residues_list[r]
                            acid = str(residue.get_resname())

                            for keys in amino_acids_frequency_bsheet:
                                if acid in amino_acids_frequency_bsheet:
                                    amino_acids_frequency_bsheet[acid] += 1
            except Exception:
                pass
            if not line:
                break

        # f = open('output.txt', 'a')

        # f.write(str(structure_id) + "\n" + 'Alpha-Helix:' + str(round(length_helix_alpha / protein_length, 3)) + "\n" +
        # '31_Helix:' + str(round(length_helix_31 / protein_length, 3)) + "\n" +
        # 'beta_Sheet:' + str(round(length_sheet / protein_length, 3)) + "\n")
        sorted_aHelix = sorted(amino_acids_frequency_aHelix.items(), key=operator.itemgetter(1), reverse=True)
        sorted_bSheet = sorted(amino_acids_frequency_bsheet.items(), key=operator.itemgetter(1), reverse=True)
        # f.close()
        g = open('sorted_list.txt', 'a')
        g.write(str(structure_id) + "\n" + 'Alpha-Helix:' + "\n" + str(sorted_aHelix) + "\n" +
                'beta_Sheet:' + "\n" + str(sorted_bSheet) + "\n")
        g.close()

        # print(sorted_aHelix)
        # print(sorted_bSheet)

        # print_histo_for_protein(hist_list, hist_list_aHelix)
        # print_histo_for_aHelix(hist_list_aHelix)

The used packages for the Nussinov algorithm are:

Numpy Version :1.20.1
Argparse Version :1.1
Pyton Version :3.8.8

Aufgabe 2:

 Please explain why only one solution is returned with the implementation from the lecture.
  
 Because in the implementation the traceback kicks in if one (if) condition is fullfilled, 
 but its possible that two conditions are fullfilled but only the first got entered.

Please explain how you would modify your algorithm to obtain a random optimal solution (just written text is sufficient, pseudo-code is not required).

If to conditions are fullfilled the point get stored and the second or more got computed form there.

Provide an estimate in O-Notation for the computational complexity of finding all optimal solutions. Explain why the method has this complexity.

O(k*n) were k are the number of solution and n the length of the sequence.
#!/usr/bin/env python
# coding: utf-8

# Implementation of the Nussinov Algorithm

import numpy as np
import argparse
import sys


print('Pyton Version :' + sys.version)
print('Numpy Version :' + np.__version__)
print('Argparse Version :' + argparse.__version__)



parser = argparse.ArgumentParser(description='Arguments for the Nussinov algorithm')

parser.add_argument('-i', type=argparse.FileType('r'))
parser.add_argument('--min-loop-length', type=int, default=3)
parser.add_argument('--score-GC', type=int, default=2)
parser.add_argument('--score-AU', type=int, default=2)
parser.add_argument('--score-GU', type=int, default=1)

args = parser.parse_args()

seq = args.i.readlines()[1:]

args.i.close()

sequence = ''

for s in seq:
    sequence += s

min_loop_length = args.min_loop_length

score_GC = args.score_GC

score_AU = args.score_AU

score_GU = args.score_GU

print('min_loop_length:' + str(min_loop_length) )

print('score_GC: ' + str(score_GC))

print('score_AU: ' + str(score_AU))

print('score_GU:' + str(score_GU))

print(sequence)

Matrix = np.zeros([len(sequence), len(sequence)])
Matrix[:] = np.nan

for i in range(1, len(sequence)):
    Matrix[i][i - 1] = 0

for i in range(0, len(sequence)):
    Matrix[i][i] = 0



def score(r, t):

    a = sequence[r]

    b = sequence[t]

    if ((a == "A" and b == "U") or (a == "U" and b == "A")):

        return score_AU

    if ((a == "G" and b == "C") or (a == "C" and b == "G")):

        return score_GC

    if ((a == "G" and b == "U") or (a == "U" and b == "G")):

        return score_GU
    else:
        return 0


for l in range(1, len(sequence)):

    # minimal of the length between i and j to form knots

    for j in range(l, len(sequence)):

        i = j - l # only the top triangle gets filled

        if i + min_loop_length < j:  # minimal length,

            Matrix[i][j] = max(Matrix[i+1][j],
                                Matrix[i][j - 1],
                                Matrix[i + 1][j - 1] + int(score(i, j)),
                                max([Matrix[i][k] + Matrix[k + 1][j] for k in range(i+1 , j)]))
        else:

            Matrix[i][j] = 0

print(Matrix)


# inisialize dotbraket

dotbrecket = ''

for e in range(0, len(sequence)):
    dotbrecket += '.'

string_list = list(dotbrecket)

pairs = ''

temp = ''


def traceback(i, j):

    if i < j:

        if Matrix[i][j] == Matrix[i + 1][j]:
            #print(i + 1, sequence[i], 0)
            traceback(i + 1, j)


        elif Matrix[i][j] == Matrix[i][j - 1]:
            #print(i + 1, sequence[i], 0)
            traceback(i, j - 1)


        elif Matrix[i][j] == Matrix[i + 1][j - 1] + score(i, j):
            print(i+1 , sequence[i], j+1)
            string_list[i] = '('
            string_list[j] = ')'
            traceback(i + 1, j - 1)

        else:

            for k in range(i + 1,j-1):

                if Matrix[i][j] == Matrix[i][k] + Matrix[k + 1][j]:

                    traceback(i, k)
                    traceback(k + 1, j)
                    break


traceback(0, len(sequence)-1)

string_list2 = ''


for r in string_list:

    string_list2 += r


print(string_list2)
print(temp)




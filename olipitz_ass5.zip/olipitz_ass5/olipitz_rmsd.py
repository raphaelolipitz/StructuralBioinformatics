import argparse
import math
from Bio.PDB import is_aa
from Bio.PDB.PDBParser import PDBParser

# parsing the referance pdb file and the predicted pdb file
parser = argparse.ArgumentParser(description='Arguments for calculating the RMSD for two protein files')

parser.add_argument('-reference', type=argparse.FileType('r'))
parser.add_argument('-predicted', type=argparse.FileType('r'))

args = parser.parse_args()

# parsing the referance file and constructing a objectlist with aa only.
par1 = PDBParser()
residues_ref_list = []
structure_ref = par1.get_structure('ref', args.reference)
residues_list = list(structure_ref.get_residues())
for residue in residues_list:
    if is_aa(residue, standard=True):
        residues_ref_list.append(residue)

# parsing the predicted file and constructing a objectlist with aa only.
par2 = PDBParser()
residues_pred_list = []
structure_pred = par2.get_structure('predicted', args.predicted)
residues_list_pred = list(structure_pred.get_residues())
for residue in residues_list_pred:
    if is_aa(residue, standard=True):
        residues_pred_list.append(residue)


# functions for the rsmd calculation
def distance(position1, position2):
    distance = (position1[0] - position2[0]) ** 2 + (position1[1] - position2[1]) ** 2 + (
                position1[2] - position2[2]) ** 2
    return distance


# for simplicity, we only uses the calpha backbone atomes to calculate the rmsd and not other backbone atomes.

summe = 0
for r in range(0, len(residues_ref_list)):

    try:
        residue_ref = residues_ref_list[r]
        residue_pred = residues_pred_list[r]
    # getting the atom coordinates of the c alpha Atomes of the reference protein and the predicted protein.

        ca_ref = residue_ref['CA'].get_vector().get_array()
        ca_pred = residue_pred['CA'].get_vector().get_array()
        print(ca_ref)
        summe += distance(ca_ref, ca_pred)
        print(summe)
    except Exception:
        continue

rmsd = math.sqrt(1 / len(residues_ref_list) * summe)

print('The computed RMSD value of your refenance protein and your predicted protein is:')
print(rmsd)

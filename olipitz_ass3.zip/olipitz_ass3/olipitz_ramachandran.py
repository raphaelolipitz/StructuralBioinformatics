import argparse
import sys
import matplotlib.pyplot as plt
import numpy as np
from Bio.PDB import is_aa
from Bio.PDB.PDBParser import PDBParser
import math

from matplotlib.backends.backend_pdf import PdfPages


def cross_product(a, b):
    assert len(a) == len(b) == 3
    # mag = math.sqrt((a[0] ** 2 + a[1] ** 2 + a[2] ** 2)) * math.sqrt(b[0] ** 2 + b[1] ** 2 + b[2] ** 2)
    cross = [0, 0, 0]

    cross[0] = (a[1] * b[2] - a[2] * b[1])
    cross[1] = (a[2] * b[0] - a[0] * b[2])
    cross[2] = (a[0] * b[1] - a[1] * b[0])

    return cross


def normalize(a):
    assert len(a) == 3
    z = np.empty(3)
    mag = math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2)
    z[0] = a[0] / mag
    z[1] = a[1] / mag
    z[2] = a[2] / mag

    return z


def dot_product(u, v):
    assert len(u) == len(v) == 3
    dot_p = u[0] * v[0] + u[1] * v[1] + u[2] * v[2]

    return dot_p


def calculate_angle(f, g):
    assert len(f) == len(g) == 3
    ratio = dot_product(f, g)
    ang = math.acos(ratio)

    return ang


def plott(a, b):
    a = plt.figure()
    a.subplots(len(args.i))
    for q in range(0, len(phi_list)):
        plt.scatter(phi_list[q], psi_list[q], c=col[q], alpha=0.5)
        title = structure.id
        plt.title(title)
        plt.xlabel('PHI')
        plt.ylabel('PSI')
        plt.xlim([-180, 180])
        plt.ylim([-180, 180])
        plt.axhline(y=0, linewidth=1)
        plt.axvline(x=0, linewidth=1)

    return a


print('Pyton Version :' + sys.version)
print('Numpy Version :' + np.__version__)
print('Argparse Version :' + argparse.__version__)

parser = argparse.ArgumentParser(description='Arguments for the Nussinov algorithm')

parser.add_argument('-i', type=argparse.FileType('r'), nargs='*')
parser.add_argument('-o')

args = parser.parse_args()

figure_list = []
torsion_list = np.empty(2 * len(args.i))
phi_list = []
psi_list = []

for input_file in args.i:
    par = PDBParser()

    # path = '/Users/raphael/Downloads/1igt.pdb'
    residues_list2 = []

    structure = par.get_structure('name', input_file)
    residues_list = list(structure.get_residues())

    for residue in residues_list:
        if is_aa(residue, standard=True):
            residues_list2.append(residue)

    for r in range(1, len(residues_list2) - 3):
        residue1 = residues_list2[r]
        residue2 = residues_list2[r + 1]
        residue3 = residues_list2[r + 2]

        nx = residue1['N'].get_vector().get_array()
        cx = residue1['C'].get_vector().get_array()
        cax = residue1['CA'].get_vector().get_array()
        ny = residue2['N'].get_vector().get_array()
        cay = residue2['CA'].get_vector().get_array()
        cy = residue2['C'].get_vector().get_array()
        nz = residue3['N'].get_vector().get_array()

        # print(n,c,ca)
        v1 = ny - cx
        v2 = cay - ny
        v3 = cy - cay

        u = cross_product(v1, v2)  # vector
        w = cross_product(v2, v3)  # vector

        norm1 = normalize(u)  # vector
        norm2 = normalize(w)  # vector

        phi = calculate_angle(norm1, norm2)  # float

        try:
            if calculate_angle(v2, w) > 0.001:
                phi = -phi
        except ZeroDivisionError:
            # dihedral=pi
            pass

        # print(angle)

        # Determine sign of angle
        # for PHI
        # 𝐧 = (𝐵−𝐴)×(𝐶−𝐵)

        # for PSI
        # 𝐧 = (𝐵−𝐴)×(𝐶−𝐵)

        u1 = cay - ny
        u2 = cy - cay

        u3 = nz - cy

        q = cross_product(v1, u2)  # vector
        s = cross_product(u2, u3)  # vector

        norm3 = normalize(q)  # vector
        norm4 = normalize(s)  # vector

        psi = calculate_angle(norm3, norm4)  # float

        try:
            if calculate_angle(u2, s) > 0.001:
                psi = -psi
        except ZeroDivisionError:
            # dihedral=pi
            pass
        # calculate vectors perpendicular to the bonds

        phi_list.append(phi)
        psi_list.append(psi)

   

    col = []

    for i in range(0, len(phi_list)):
        # phi = -140 degrees and psi = 130 degrees
        if phi_list[i] == -140 and psi_list[i] == 130:
            col.append('red')
        # beta-fold
        elif phi_list[i] == -60 and psi_list[i] == -45:
            col.append('blue')
        else:
            col.append('green')

    figure_list.append(plott(phi_list, psi_list))
    
for i in args.i:

    pp = PdfPages(args.o)
    pp.savefig()

pp.close()

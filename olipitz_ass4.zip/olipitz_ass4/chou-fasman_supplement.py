import numpy as np

# helix p_alpha relative probabilities
p_a = {
    'E': 1.53, 'A': 1.45, 'L': 1.34, 'H': 1.24, 'M': 1.20, 'Q': 1.17, 'W': 1.14, 'V': 1.14, 'F': 1.12,  # builders
    'K': 1.07, 'I': 1.00, 'D': 0.98, 'T': 0.82, 'S': 0.79, 'R': 0.79, 'C': 0.77,  # indifferent
    'N': 0.73, 'Y': 0.61, 'P': 0.59, 'G': 0.53  # breakers
}

# helix builder/indifferent/breaker class weights
w_a = {aa: (1 if score > 1.1 else -1 if score < 0.75 else 0.5) for aa, score in p_a.items()}

# strand p_beta relative probabilities
p_b = {
    'M': 1.67, 'V': 1.65, 'I': 1.60, 'C': 1.30, 'Y': 1.29, 'F': 1.28, 'Q': 1.23, 'L': 1.22, 'T': 1.20, 'W': 1.19,
    # builders
    'A': 0.97, 'R': 0.90, 'G': 0.81, 'D': 0.80,  # indifferent
    'K': 0.74, 'S': 0.72, 'H': 0.71, 'N': 0.65, 'P': 0.62, 'E': 0.26  # breakers
}

# strand builder/indifferent/breaker class weights
# changed to 2/0/-1 encoding for convenience, so that a window of 5 is a strand core if sum(window) >= 5.
w_b = {aa: (2 if score > 1 else -1 if score < 0.78 else 0) for aa, score in p_b.items()}

# sequence of 5JXV
seq = 'MQYKLILNGKTLKGETTTEAVDAATAEKVFKQYANDNGVDGEWTYDDATKTFTVTE'

# reference secondary structure for accuracy calculation
ss_ref = '-SSSSSSS----SSSSSSS---HHHHHHHHHHHHHH-----SSSSS----SSSSS-'

# implementing list for value of the predictions
helix_liste = np.zeros(len(seq))
beta_sheet = np.zeros(len(seq))
print(beta_sheet)

# implementing temp lists
index_start_list_for_helix_cores = []
index_end_list_for_helix_cores = []
index_start_list_for_bsheet_cores = []
index_end_list_for_bsheet_cores = []

# lists for w_a and w_b values
list = []
list_bb = []

# filling list with the coresponding w_a values
for aa in seq:
    for key, value in w_a.items():
        if key == aa:
            list.append(value)

# filling list with the coresponding w_b values
for aa in seq:
    for key, value in w_b.items():
        if key == aa:
            list_bb.append(value)

b = 5
ct = 0
startb = 0
endb = 0
starth = 0
endh = 0
l = 4
sum = 0
k = 6

# first sliding window for core bShild prediction
for i in range(0, 4):
    ct += list_bb[i]
    if ct >= 5:
        startb = i
        endb = i
        index_end_list_for_bsheet_cores.append(i)
        index_start_list_for_bsheet_cores.append(i)
# extension to the rigth side of first betaSheet prediction
for u in range(startb, len(list_bb)):
    if beta_sheet[u + 1] == 0:
        ct = ct + p_b.get(seq[u]) - p_b.get(seq[u - b])
        if ct >= 4:
            beta_sheet[u] = ct
        if ct < 4:
            break
    else:
        break
# extension to the left side of first betaSheet prediction
for z in range(endb, 0):
    if beta_sheet[z - 1] == 0:
        ct = ct + p_b.get(seq[z - b]) - p_b.get(seq[z])
        if ct >= 4:
            beta_sheet[z - b] = ct
        if ct < 4:
            break
    else:
        break

# So it seam to be that the mean fail is the check if no other core got extended.
for i in range(5, len(list_bb)):
    ct = ct + list_bb[i] - list_bb[i - l]
    if ct >= 5:
        startb = i
        endb = i - l
        if endb not in index_end_list_for_bsheet_cores:
            if startb not in index_start_list_for_bsheet_cores:
                index_end_list_for_bsheet_cores.append(i)
                index_start_list_for_bsheet_cores.append(i - l)
                # extension to the rigth side of betaSheet prediction
for u in index_end_list_for_bsheet_cores:
    try:
        if index_start_list_for_bsheet_cores[u] < index_start_list_for_bsheet_cores[z+1]:
            ct = ct + p_b.get(seq[u]) - p_b.get(seq[u - l])
            if ct >= 4:
                beta_sheet[u] = ct
            if ct < 4:
                break
        else:
            break
    except Exception:
        continue
# extension to the left side of betaSheet prediction
for z in index_start_list_for_bsheet_cores:
    if index_start_list_for_bsheet_cores[z] > index_start_list_for_bsheet_cores[z-1]:
        ct = ct + p_b.get(seq[z - l]) - p_b.get(seq[z])
        if ct >= 4:
            beta_sheet[z - l] = ct
        if ct < 4:
            break
    else:
        break

for i in range(0, 5):
    sum += list[i]
    if sum >= 4:
        index_end_list_for_helix_cores[0] = i
        index_start_list_for_helix_cores[0] = 0

for i in range(6, len(list)):
    sum = sum + list[i] - list[i - k]
    if sum >= 4:
        starth = i
        endh = i - k
        if endh not in index_end_list_for_helix_cores:
            if starth not in index_start_list_for_helix_cores:
                index_end_list_for_helix_cores.append(i)
                index_start_list_for_helix_cores.append(i - k)
                # extension to the rigth side of aHelix prediction
                for o in range(starth, len(list)):
                    sum = sum + p_a.get(seq[o]) - p_a.get(seq[o - l])
                    if sum >= 4:
                        helix_liste[o] = sum
                    if sum < 4:
                        break
                    # extansion for the left side of aHelix prediction.
                for p in range(endh, 0):
                    sum = sum + p_a.get(seq[p - l]) - p_a.get(seq[p])
                    if sum >= 4:
                        helix_liste[p - l] = sum
                    if sum < 4:
                        break

summe_a = 0
summe_b = 0
final_list = []

# Conflict handling for aHelix and bSheets

for u in range(0, len(seq)):

    summe_a += summe_a + helix_liste[u] - helix_liste[u - 4]
    summe_b += summe_b + beta_sheet[u] - beta_sheet[u - 4]
    Pa = summe_a / 4
    Pb = summe_b / 4
    if Pa < Pb:
        final_list.append('S')
    if Pb < Pa:
        final_list.append('H')
    else:
        final_list.append('-')

print(index_start_list_for_helix_cores)
print(index_end_list_for_helix_cores)
print(index_start_list_for_bsheet_cores)
print(index_end_list_for_bsheet_cores)
print(beta_sheet)
print(helix_liste)
print(final_list)
# conflict handling
final = ''
for i in final_list:
    final += i

g = open('predicted.txt', 'a')

g.write(seq +"\n" + final + "\n" + ss_ref)
g.close()
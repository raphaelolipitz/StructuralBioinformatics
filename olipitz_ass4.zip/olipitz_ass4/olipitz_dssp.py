import math
import numpy as np
from Bio.PDB import *
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def calculate_absolute_value(value):
    if value <=0:
        return math.sqrt(value**2)
    else:
        return value

# because the slides are a bit wrong in a way, I used the formula from wiki,
# because the wikipedia articel is from Sanders et all
# i think ist okay to use it.
def calculating_energy(a, b, c):
    energy = 0.084 * ((1 / calculate_absolute_value(a)) + (1 /calculate_absolute_value(b)) * (1 / calculate_absolute_value(c)) * 332)
    return energy

def calculating_distance(vector1, vector2):

    distance = math.sqrt((vector1[0]-vector2[0]) ** 2 + (vector1[1]-vector2[1]) ** 2 + (vector1[2]-vector2[2]) **2)

    return distance

path = '/Users/raphael/Documents/Studium/Vorlesungen/StructureBioinformatik/pythonProject/5jxv.pdb'
parser = PDBParser()
structure = parser.get_structure('structure_id', path)
model = structure[0]
c = 0
residue_list = []
for residue in model.get_residues():
    c += 1
    if is_aa(residue, standard=True):
        residue_list.append(residue)
print(c)

#implementing empty matrix for filling with energy values
dssp_matrix = np.empty([len(residue_list), len(residue_list)])

for i in range(0, len(residue_list)):
    for j in range(0, len(residue_list)):
        residue1 = residue_list[i]
        residue2 = residue_list[j]
        o = residue1['O'].get_vector()
        n = residue2['N'].get_vector()
        h = residue2['H'].get_vector()
        c = residue1['C'].get_vector()

        ron = calculating_distance(o , n)
        roh = calculating_distance(o , h)
        rcn = calculating_distance(c , n)
        dssp_matrix[i][j] = calculating_energy(ron, roh, rcn)

print(dssp_matrix)

# printing heatmap---correct in test.
# making a tsv file in matrix form not only in row
np.savetxt("dssp_matrix.tsv",dssp_matrix, delimiter="")
df = pd.DataFrame(dssp_matrix)
print(df)
fig, ax = plt.subplots(figsize=(8, 8))
# plot heatmap
sns.heatmap(df, cmap="Blues", linewidth=0.3, cbar_kws={"shrink": .8})
fig1 = plt.gcf()
#plt.show()
fig1.savefig(fname='test2.pdf')

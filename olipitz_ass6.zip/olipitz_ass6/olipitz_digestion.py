#imported packages
import argparse
import re
from Bio.Seq import Seq
from Bio import SeqIO

# isotrophhic mass of the amino accides
mass_isomorphic = {
    'E': 129.04259, 'A': 71.03711, 'L': 113.08406, 'H': 137.05891, 'M': 131.04049, 'Q': 128.05858, 'W': 186.07931, 'V': 99.06841, 'F': 147.06841,
    'K': 128.09496, 'I': 113.08406, 'D': 115.02694, 'T': 101.04768, 'S': 87.03203, 'R': 156.10111, 'C': 103.00919,
    'N': 114.04293, 'Y': 99.06841, 'P': 97.05276, 'G': 97.05276
}

# average mass of amino accides
mass_average = {
    'E': 129.1155, 'A': 71.0788, 'L': 113.1594, 'H': 137.1411, 'M': 131.1926, 'Q': 128.1307, 'W': 186.2132, 'V': 99.1326, 'F': 147.1766,
    'K': 128.1741, 'I': 113.1594, 'D': 115.0886, 'T': 101.1051, 'S': 87.0782, 'R': 156.1875, 'C': 103.1388,
    'N': 114.1038, 'Y': 163.1760, 'P': 97.1167, 'G': 57.0519
}

# function for calculating the isomorphic mass of a peptide
def calculating_isomorphic_mass(peptide):
    mass = 0

    for aa in peptide:
        if aa in mass_isomorphic:

            mass += mass_isomorphic[aa]

    return mass

#function for calculating the average mass of a peptide
def calculating_avverage_mass(peptide):
    mass = 0

    for aa in peptide:
        if aa in mass_average:

            mass += mass_average[aa]

    return mass


# function that calculate the in silico digest the protein
def calculating_in_silico_digest_index(protein):
    for i in range(0,len(protein)-1):
        if protein[i]=='K' and protein[i+1]!='P':
            digest_index.append(i+1)
        elif protein[i]=='R' and protein[i+1]!='P':
            digest_index.append(i+1)

# function too calculate the peptides
def calculating_in_silico_digest_peptide(index_array):
    for j in range(0, len(digest_index) - 1):
        digest.append(protein[digest_index[j]:digest_index[j + 1]])


#comandline options and user input
parser = argparse.ArgumentParser(description='Arguments for the trypsin digestion')
parser.add_argument('-i', type=argparse.FileType('r'))
args = parser.parse_args()
#read fasta-file with biopython

#parsing the fasta file input
protein = ''
for sequence in SeqIO.parse(args.i, "fasta"):
    protein = str(sequence.seq)


#trypsin digest if a arginin(A) or a Lysin(K) occores

digest_index = []
digest = []


#calculating the indexes of the digest protein
calculating_in_silico_digest_index(protein)
print (digest_index)
calculating_in_silico_digest_peptide(digest_index)
digest.sort(key = len)
digest.reverse()
# calculating isotriphic mass of digested protein
mass_isomorphic_digest = []
for peptide in digest:
    mass_isomorphic_digest.append(calculating_isomorphic_mass(peptide))


digest.sort(key = len)
digest.reverse()
print(digest)


mass_average_digest = []
for peptide in digest:
    mass_average_digest.append(calculating_avverage_mass(peptide))



dictionary_isomor = dict(zip(digest,mass_isomorphic_digest))
dictionary_average = dict(zip(digest,mass_average_digest))
print('Monoisomorphic Masses:')
print(dictionary_isomor)
print('Average Masses:')
print(dictionary_average)
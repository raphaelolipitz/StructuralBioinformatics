# isotrophhic mass of the amino accides
mass_isomorphic = {
    'E': 129.04259, 'A': 71.03711, 'L': 113.08406, 'H': 137.05891, 'M': 131.04049, 'Q': 128.05858, 'W': 186.07931,
    'V': 99.06841, 'F': 147.06841,
    'K': 128.09496, 'I': 113.08406, 'D': 115.02694, 'T': 101.04768, 'S': 87.03203, 'R': 156.10111, 'C': 103.00919,
    'N': 114.04293, 'Y': 99.06841, 'P': 97.05276, 'G': 97.05276
}


# function for calculating the isomorphic mass of a peptide
def calculating_isomorphic_mass(fragment):
    mass = 0

    for aa in fragment:
        if aa in mass_isomorphic:
            mass += mass_isomorphic[aa]

    return mass

# calculating the charge to mass ratio for fragments
def calculating_mass_to_charge_ratio(masses):
    charge_to_mass = 1/masses
    return charge_to_mass


peptide = "HFEEDMGRK"
ions_array = []
# iterating over all amino accides in the peptide. first from left to rigth and than from rigth to left
for i in range(1, len(peptide)):
    fragment = peptide[0:i]
    ions_array.append(fragment)

for i in range(1, len(peptide)):
    fragment = peptide[i:len(peptide)]
    ions_array.append(fragment)

#sorting the array to get a good dictionary
mass_isomorphic_array = []
ions_array.sort(key=len)
ions_array.reverse()

# calculating for every fragment the mass
for fragment in ions_array:
    mass_isomorphic_array.append(calculating_isomorphic_mass(fragment))

#printing the dictonary for the masses and the fragments
dictionary_isomor = dict(zip(ions_array,mass_isomorphic_array))
print(dictionary_isomor)

#computing the charge to mass ratio for every fragment
charge_to_mass_array = []

for fr in mass_isomorphic_array:
    charge_to_mass_array.append(calculating_mass_to_charge_ratio(fr))

#making the dictionary for the charge to mass ratio
dictionary_char_to_mass = dict(zip(ions_array,charge_to_mass_array))
print(dictionary_char_to_mass)


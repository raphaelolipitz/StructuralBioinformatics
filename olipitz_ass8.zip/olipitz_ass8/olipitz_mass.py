import csv
from itertools import product


# open the csv file for getting the m/z data provided form the tutors.
import math

import numpy as np

file = open("b_y_spectrum.txt", "r")
csv_reader = csv.reader(file)
lists_from_csv = []
for row in csv_reader:
    lists_from_csv.append(row[0])
signals = [float(i) for i in lists_from_csv]

# dictonarry for the aminoacides masses to compare.
mass_isomorphic = {
    'E': 129.04259, 'A': 71.03711, 'L': 113.08406, 'H': 137.05891, 'M': 131.04049, 'Q': 128.05858, 'W': 186.07931,
    'V': 99.06841, 'F': 147.06841,
    'K': 128.09496, 'I': 113.08406, 'D': 115.02694, 'T': 101.04768, 'S': 87.03203, 'R': 156.10111, 'C': 103.00919,
    'N': 114.04293, 'Y': 99.06841, 'P': 97.05276, 'G': 97.05276
}

# Core Idear of the Algorithm is to take the y ions and take the difference of them to get the missing weigths of the
# Amino acide with that the amino acide get searched in the dictionary and appand on the potential peptide/protein sequence.
array_of_mass_difference = []


def calculating_difference(a, b):
    diff = b - a
    return diff


def unique(array):
    result = []
    for x in array:
        if x not in result:
            result.append(x)
    return result


def replacer(string, newstring, index):
    # if not erroring, but the index is still not in the correct range..
    if index < 0:  # add it to the beginning
        return newstring + string
    if index > len(string):  # add it to the end
        return string + newstring
    # insert the new string between "slices" of the original
    return string[:index] + newstring + string[index + 1:]


# First signal got appended because its a single amino acide.
array_of_mass_difference.append(signals[0] - 1)
# print(array_of_mass_difference)


for i in range(0, len(signals) - 2, 2):
    array_of_mass_difference.append(calculating_difference(signals[i], signals[i + 2]))

protein_sequence = []

for diff in array_of_mass_difference:
    for key, value in mass_isomorphic.items():
        if abs(diff - value) <= 0.1:
            protein_sequence.append(key)
            break

peptid = ""

array_of_fragments = []

for j in protein_sequence:
    peptid += j
    array_of_fragments.append(peptid)
print(array_of_fragments)

array_of_combinations = []
'''''
for chr in range(0, len(peptid)):
    if peptid[chr] == 'L':
        fragment2 = replacer(peptid, 'I', chr)
        array_of_combinations.append(fragment2)

for chr in range(0, len(peptid)):
    if peptid[chr] == 'Q':
        fragment2 = replacer(peptid, 'K', chr)
        array_of_combinations.append(fragment2)



print(len(array_of_com))

'''''

switch_dict = {'L': ['I'], 'Q': ['K']}


for key in switch_dict.keys():
    if key not in switch_dict[key]:
        switch_dict[key].append(key)
print(switch_dict)

result = []

for fragment in array_of_fragments:

    test_str = peptid

    for substring in [zip(switch_dict.keys(), chr) for chr in product(*switch_dict.values())]:
        temp = test_str
        for repls in substring:
        # replacing all elements at once using * operator
            temp = temp.replace(*repls)
        result.append(temp)

'''''


def recursion(array):
    result = []
    if len(array) == 0:
        return result
        print('hey')
    if array[0] == 'L':
        print('hallo')
        result.append('I' + array[:len(array)])
        result.append(array)
        recursion(array[1:len(array)])


'''''

print(result)
print(len(result))